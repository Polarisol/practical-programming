from PySide6.QtWidgets import QApplication, QWidget, QPushButton
from OtherWindow import OtherWindow 
# 1. Import the OtherWindow class to be used in the main window

class MainWindow(QWidget):

    def __init__(self):
        super().__init__()
        self.other_window = OtherWindow(self) # 2. we are passing self (us.. the main window) 
        self.initUI()                         #    to the other window so it can access our variables and methods

    def initUI(self):
        self.setWindowTitle("Window Title")
        self.setGeometry(100, 100, 400, 300)    

        self.button = QPushButton("Open Other Window", self)
        self.button.setGeometry(20, 20, 200, 40)  
        self.button.clicked.connect(self.open_other_window)

    def open_other_window(self):
        self.other_window.show() # 3. show the other window when the button is clicked

if __name__ == "__main__":
    app = QApplication()
    window = MainWindow()
    window.show()
    app.exec()



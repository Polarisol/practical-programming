from PySide6.QtWidgets import QApplication, QWidget

class OtherWindow(QWidget):

    def __init__(self, main_window=None):
        super().__init__()
        self.main_window = main_window
        # the variables and methods of the main window can
        # be accessed in this class through self.main_window
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Window Title")
        self.setGeometry(200, 200, 300, 200)      

if __name__ == "__main__":
    # this code will run only if this file is executed directly
    # showing the window as its own application
    app = QApplication()
    window = OtherWindow()
    window.show()
    app.exec()